package com.example.study1106;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Study1106Application {

    public static void main(String[] args) {
        SpringApplication.run(Study1106Application.class, args);
    }

}
