package com.example.study1106;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Study1106ApplicationTests {

    @Test
    void contextLoads() {
    }

}
